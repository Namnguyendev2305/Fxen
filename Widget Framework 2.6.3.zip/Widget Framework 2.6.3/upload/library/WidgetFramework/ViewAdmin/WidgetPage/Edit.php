<?php

class WidgetFramework_ViewAdmin_WidgetPage_Edit extends WidgetFramework_ViewAdmin_Widget_List
{
}
